﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Foods
{
    public class Fruit : Food
    {
        public Fruit(int foodQuantity) : base(foodQuantity)
        {
        }
    }
}
