﻿
namespace BorderControl
{
    public interface ICheckerId
    {
        void Add(string id);
        void Checker(string id);
    }
}
