﻿
namespace Telephony
{
    public interface IBrowsable : ICallable
    {
        string Browsing(string n);
    }
}
