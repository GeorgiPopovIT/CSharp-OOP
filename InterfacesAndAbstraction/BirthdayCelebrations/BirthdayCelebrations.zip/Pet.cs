﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebrations
{
    public class Pet : IContainsc
    {
        public Pet(string birtDayDate)
        {
            BirthdayDate = birtDayDate;
        }
        public string BirthdayDate { get; set; }
    }
}
