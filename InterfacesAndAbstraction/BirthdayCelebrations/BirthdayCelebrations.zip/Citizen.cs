﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebrations
{
    public class Citizen : IContainsc
    {
        public Citizen(string birthdayDate)
        {
            BirthdayDate = birthdayDate;
        }
        public string BirthdayDate { get; set; }
    }
}
