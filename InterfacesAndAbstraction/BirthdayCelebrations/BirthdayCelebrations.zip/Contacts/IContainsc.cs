﻿
namespace BirthdayCelebrations
{
    public interface IContainsc
    {
        public string BirthdayDate { get; set; }
    }
}
