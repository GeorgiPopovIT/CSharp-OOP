﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Restaurant.Beverage
{
    public class HotBeverage : Beverage
    {
        public HotBeverage(string name, decimal price,double mililitres)
            :base(name,price,mililitres)
        {

        }
    }
}
