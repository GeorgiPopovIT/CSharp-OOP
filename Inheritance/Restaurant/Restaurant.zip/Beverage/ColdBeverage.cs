﻿

namespace Restaurant.Beverage
{
   public class ColdBeverage : Beverage
    {
        public ColdBeverage(string name, decimal price, double mililiters)
            :base(name,price,mililiters)
        {

        }
    }
}
