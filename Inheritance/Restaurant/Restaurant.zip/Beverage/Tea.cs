﻿

namespace Restaurant.Beverage
{
   public class Tea : HotBeverage
    {
        public Tea(string name,decimal price,double mililitres)
            :base(name,price,mililitres)
        {

        }
    }
}
